import React, { useState, useCallback, useMemo } from 'react';
import { Item, Character } from '../types';

interface InventoryProps {
  character: Character;
  onClose: () => void;
  storyDirection: string;
  onUpdateStoryDirection: (val: string) => void;
}

const Inventory: React.FC<InventoryProps> = ({ character, onClose, storyDirection, onUpdateStoryDirection }) => {
  const [hoveredItem, setHoveredItem] = useState<Item | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
  }, []);

  const inventoryData = useMemo(() => {
    const containers: Item[] = character.inventory.filter(i => i.type === 'container');
    const itemsByContainer: Record<string, Item[]> = {};
    const rootItems: Item[] = [];

    character.inventory.forEach(item => {
      if (item.type === 'container') return;
      if (item.containerId) {
        if (!itemsByContainer[item.containerId]) itemsByContainer[item.containerId] = [];
        itemsByContainer[item.containerId].push(item);
      } else {
        rootItems.push(item);
      }
    });

    const equipped = rootItems.filter(i => !!i.slot);
    const loose = rootItems.filter(i => !i.slot);

    return { containers, itemsByContainer, equipped, loose };
  }, [character.inventory]);

  const calculateEffectiveStat = (item: Item, stat: 'damage' | 'armorRating') => {
    const base = item.stats?.[stat] || 0;
    if (item.durability <= 0) return 0;
    return base;
  };

  const renderItemCard = (item: Item, isInsideContainer: boolean = false) => {
    const isBroken = item.durability <= 0;
    const isBolstered = item.durability > 100;

    return (
      <div 
        key={item.id} 
        onMouseEnter={() => setHoveredItem(item)}
        onMouseLeave={() => setHoveredItem(null)}
        onMouseMove={handleMouseMove}
        className={`group relative p-3 bg-slate-900/40 border rounded-lg transition-all cursor-help flex justify-between items-center
          ${isBroken ? 'border-red-900/30 opacity-60 grayscale' : 'border-slate-800 hover:border-amber-600/50 hover:bg-slate-800/40'}
          ${isInsideContainer ? 'border-l-4 border-l-amber-900/40 ml-2' : ''}
        `}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={`font-header text-sm truncate ${isBolstered ? 'text-amber-400' : 'text-slate-200'} group-hover:text-white`}>
              {item.name}
            </span>
            {item.slot && (
              <span className="text-[8px] px-1.5 py-0.5 bg-amber-900/20 text-amber-500 rounded border border-amber-900/40 font-bold uppercase">
                {item.slot}
              </span>
            )}
          </div>
          <div className="flex gap-3 mt-1 text-[9px] font-bold uppercase tracking-tighter text-slate-500">
             {item.stats?.damage && <span>Dmg: {calculateEffectiveStat(item, 'damage')}</span>}
             {item.stats?.armorRating && <span>Prot: {calculateEffectiveStat(item, 'armorRating')}</span>}
             <span className={isBroken ? 'text-red-500' : isBolstered ? 'text-amber-400' : ''}>
               {item.durability}% Durability
             </span>
          </div>
        </div>
        <div className="text-right flex-shrink-0 ml-3">
          <div className="text-amber-500 font-mono text-xs">{item.value}g</div>
          <div className="text-slate-600 text-[9px]">{item.weight} lb</div>
        </div>
      </div>
    );
  };

  const renderBag = (bag: Item) => {
    const contents = inventoryData.itemsByContainer[bag.id] || [];
    
    return (
      <div key={bag.id} className="bg-slate-950/60 border border-amber-900/30 rounded-2xl overflow-hidden shadow-2xl relative group/bag">
        <div className="p-4 border-b border-amber-900/20 flex justify-between items-center bg-gradient-to-r from-amber-950/40 to-slate-950">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg border bg-amber-900/40 border-amber-600/50 text-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
              <i className="fas fa-toolbox"></i>
            </div>
            <div>
              <h4 className="text-[12px] font-header text-slate-100 uppercase tracking-widest">{bag.name}</h4>
              <p className="text-[8px] text-slate-500 uppercase font-bold tracking-tighter">{contents.length} Items</p>
            </div>
          </div>
        </div>
        <div className="p-4 space-y-3 bg-black/20">
          {contents.map(item => renderItemCard(item, true))}
        </div>
      </div>
    );
  };

  const Tooltip = () => {
    if (!hoveredItem) return null;
    return (
      <div 
        className="fixed z-[100] pointer-events-none bg-slate-900/95 border border-amber-900/50 p-5 rounded-2xl shadow-2xl backdrop-blur-xl w-72 flex flex-col gap-3"
        style={{ left: Math.min(mousePos.x + 20, window.innerWidth - 300), top: Math.min(mousePos.y + 20, window.innerHeight - 300) }}
      >
        <header className="border-b border-amber-900/20 pb-2">
          <h4 className="text-lg font-header text-slate-100">{hoveredItem.name}</h4>
          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">{hoveredItem.type}</span>
        </header>
        <p className="text-xs text-slate-300 italic">"{hoveredItem.description}"</p>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center p-0 md:p-8 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-300">
      <Tooltip />
      <div className="w-full h-full max-w-4xl bg-slate-900 md:rounded-3xl border-none md:border border-slate-800 overflow-hidden flex flex-col shadow-[0_0_80px_rgba(0,0,0,1)]">
        
        <div className="p-6 md:p-8 border-b border-slate-800 bg-slate-900/40 flex justify-between items-end">
          <div>
            <h2 className="text-3xl font-header text-amber-500 tracking-wider uppercase mb-1">Gear & Influence</h2>
            <p className="text-[10px] text-slate-500 uppercase tracking-[0.3em] font-bold">Physical Inventory & Narrative Intent</p>
          </div>
          <button onClick={onClose} className="w-12 h-12 flex items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white transition-all shadow-lg hover:rotate-90">
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-12 custom-scrollbar">
          
          <section className="bg-amber-950/10 border border-amber-900/20 p-6 rounded-2xl">
            <h3 className="text-[10px] font-header text-amber-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-3">
              <i className="fas fa-pen-nib"></i> Narrative Influence
            </h3>
            <p className="text-[10px] text-slate-500 italic mb-3">Guide the story (e.g., "focus on combat", "increase Vexal invasive thoughts").</p>
            <textarea 
              value={storyDirection} 
              onChange={(e) => onUpdateStoryDirection(e.target.value)}
              placeholder="Whisper your intent to the fates..." 
              className="w-full bg-slate-950 border border-slate-800 p-4 rounded-xl text-xs text-slate-300 focus:outline-none focus:border-amber-600 h-24 resize-none"
            />
          </section>

          {inventoryData.equipped.length > 0 && (
            <section>
              <h3 className="text-[10px] font-header text-slate-500 uppercase tracking-[0.2em] mb-4">Equipped Regalia</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {inventoryData.equipped.map(item => renderItemCard(item))}
              </div>
            </section>
          )}

          <section className="space-y-8">
            <h3 className="text-[10px] font-header text-amber-600/60 uppercase tracking-[0.2em] mb-4">Containers</h3>
            <div className="grid grid-cols-1 gap-6">
              {inventoryData.containers.map(bag => renderBag(bag))}
            </div>
          </section>

          {inventoryData.loose.length > 0 && (
            <section>
              <h3 className="text-[10px] font-header text-slate-500 uppercase tracking-[0.2em] mb-4">Loose Belongings</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {inventoryData.loose.map(item => renderItemCard(item))}
              </div>
            </section>
          )}

        </div>

        <div className="p-6 md:p-8 bg-slate-950/80 border-t border-slate-800 flex justify-between items-center">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest mb-1">Weight</span>
              <span className="text-sm font-header text-slate-300">
                {character.inventory.reduce((acc, i) => acc + i.weight, 0).toFixed(1)} lb
              </span>
            </div>
          </div>
          <div className="flex items-center gap-3 px-8 py-3 bg-amber-600/10 border border-amber-600/40 rounded-2xl shadow-lg">
             <i className="fas fa-coins text-amber-500 text-xl"></i>
             <span className="font-header text-2xl text-amber-500">{character.currency}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Inventory;