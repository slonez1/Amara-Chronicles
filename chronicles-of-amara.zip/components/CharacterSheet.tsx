import React, { useState, useEffect } from 'react';
import { GameState, Character, Race, SkillCategory } from '../types';
import { SKILL_LEDGER, CONDITION_LORE } from '../constants';
import StatBar from './StatBar';
import Codex from './Codex';

interface CharacterSheetProps {
  gameState: GameState;
  onClose: () => void;
}

const CharacterSheet: React.FC<CharacterSheetProps> = ({ gameState, onClose }) => {
  const [activeTab, setActiveTab] = useState<'Attributes' | 'Skills' | 'Spells' | 'Memory' | 'Codex'>('Attributes');
  const [hoveredCondition, setHoveredCondition] = useState<string | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const { character } = gameState;

  useEffect(() => {
    const handleGlobalClick = () => setHoveredCondition(null);
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
  };

  const getMasteryLevel = (val: number) => {
    if (val === 0) return 'Untrained';
    if (val < 25) return 'Novice';
    if (val < 50) return 'Adept';
    if (val < 75) return 'Expert';
    if (val < 90) return 'Master';
    return 'Grandmaster';
  };

  const getMasteryColor = (val: number) => {
    if (val === 0) return 'text-slate-600';
    if (val < 25) return 'text-slate-400';
    if (val < 50) return 'text-blue-400';
    if (val < 75) return 'text-purple-400';
    if (val < 90) return 'text-amber-400';
    return 'text-amber-500 shadow-[0_0_5px_rgba(245,158,11,0.5)]';
  };

  const ConditionTooltip = () => {
    if (!hoveredCondition) return null;
    const description = CONDITION_LORE[hoveredCondition] || 'A lingering effect upon your soul, influencing your fate and form.';
    
    return (
      <div 
        className="fixed z-[100] pointer-events-none bg-slate-900/95 border border-amber-900/50 p-4 rounded-xl shadow-2xl backdrop-blur-xl animate-in zoom-in-95 duration-200 max-w-xs"
        style={{ left: mousePos.x + 20, top: mousePos.y + 20 }}
      >
        <h4 className="text-xs font-header text-amber-500 uppercase tracking-widest mb-2 border-b border-amber-900/20 pb-1">{hoveredCondition}</h4>
        <p className="text-[10px] text-slate-300 italic leading-relaxed">"{description}"</p>
      </div>
    );
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'Attributes':
        return (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Object.entries(character.attributes).map(([key, val]) => (
              <div key={key} className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl flex flex-col items-center">
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">{key}</span>
                <span className="text-3xl font-header text-amber-500">{val}</span>
              </div>
            ))}
          </div>
        );
      case 'Skills':
        return (
          <div className="space-y-8">
            {Object.entries(SKILL_LEDGER).map(([category, skills]) => (
              <div key={category}>
                <h4 className="text-[10px] font-header text-slate-500 uppercase tracking-[0.2em] mb-4 border-b border-slate-800 pb-2">{category} Archetype</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3">
                  {skills.map(skill => {
                    const value = character.skills[skill] || 0;
                    return (
                      <div key={skill} className="flex justify-between items-center group">
                        <div className="flex flex-col">
                          <span className="text-xs font-bold text-slate-300 uppercase tracking-tight group-hover:text-amber-500 transition-colors">{skill}</span>
                          <span className={`text-[8px] font-mono uppercase ${getMasteryColor(value)}`}>{getMasteryLevel(value)}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-24 h-1 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                            <div className="h-full bg-amber-600 transition-all duration-1000" style={{ width: `${value}%` }}></div>
                          </div>
                          <span className="text-xs font-mono text-amber-500 w-8 text-right">{value}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        );
      case 'Spells':
        return (
          <div className="space-y-6">
            <div>
              <h4 className="text-[10px] font-header text-amber-600 uppercase tracking-[0.2em] mb-3">Divine Spells</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {character.spells.map((spell, idx) => (
                  <div key={idx} className="bg-slate-900/50 border border-slate-800 p-3 rounded-lg">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-sm font-bold text-slate-200">{spell.name}</span>
                      <span className="text-[9px] text-blue-400 font-mono">{spell.manaCost} MP</span>
                    </div>
                    <p className="text-[10px] text-slate-500 italic mb-2">{spell.description}</p>
                    <div className="text-[9px] font-bold text-amber-700 uppercase tracking-tighter bg-amber-950/20 px-2 py-0.5 rounded inline-block">
                      {spell.effect}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-[10px] font-header text-red-600 uppercase tracking-[0.2em] mb-3">Martial Maneuvers</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {character.maneuvers.map((man, idx) => (
                  <div key={idx} className="bg-slate-900/50 border border-slate-800 p-3 rounded-lg">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-sm font-bold text-slate-200">{man.name}</span>
                      <span className="text-[9px] text-green-400 font-mono">{man.staminaCost} SP</span>
                    </div>
                    <p className="text-[10px] text-slate-500 italic mb-2">{man.description}</p>
                    <div className="text-[9px] font-bold text-red-700 uppercase tracking-tighter bg-red-950/20 px-2 py-0.5 rounded inline-block">
                      {man.effect}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      case 'Memory':
        const vaultFullPercent = (gameState.memoryVault.length / 12) * 100;
        return (
          <div className="space-y-10 animate-in fade-in duration-500">
             <div className="p-6 bg-slate-950/40 border border-blue-900/30 rounded-2xl">
               <h4 className="text-[10px] font-header text-blue-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
                 <i className="fas fa-brain"></i> Permanent Neural Summary
               </h4>
               <p className="text-xs text-slate-300 leading-relaxed italic whitespace-pre-wrap">{gameState.memorySummary || "The Vexal's logic gates are still processing your origin..."}</p>
             </div>
             
             <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-[10px] font-header text-slate-500 uppercase tracking-[0.2em]">Archival Vault Capacity</h4>
                  <span className="text-[9px] font-mono text-slate-400">{gameState.memoryVault.length} / 12 segments</span>
                </div>
                <div className="w-full h-2 bg-slate-950 rounded-full border border-slate-800 overflow-hidden">
                   <div className={`h-full transition-all duration-700 ${vaultFullPercent > 80 ? 'bg-amber-600 shadow-[0_0_8px_rgba(217,119,6,0.4)]' : 'bg-blue-600'}`} style={{ width: `${vaultFullPercent}%` }}></div>
                </div>
                <p className="mt-2 text-[9px] text-slate-600 uppercase font-bold tracking-tighter">Oldest events move here. When full, they condense into the Summary above.</p>
             </div>

             <div>
               <h4 className="text-[10px] font-header text-slate-500 uppercase tracking-[0.2em] mb-4 border-b border-slate-800 pb-2 flex justify-between">
                 <span>Recent History</span>
                 <span className="text-amber-600/50">Immediate AI Focus</span>
               </h4>
               <div className="space-y-4">
                  {gameState.narrativeHistory.slice(-5).map((v, i) => (
                    <div key={i} className="p-4 bg-slate-900/30 border border-slate-800 rounded-xl">
                      <p className="text-[11px] text-slate-400 leading-relaxed">...{v.length > 200 ? v.substring(0, 200) + "..." : v}</p>
                    </div>
                  ))}
               </div>
             </div>
          </div>
        );
      case 'Codex':
        return <Codex entries={gameState.codex} />;
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center p-0 md:p-8 bg-black/95 backdrop-blur-3xl animate-in fade-in duration-300">
      <ConditionTooltip />
      <div className="w-full h-full max-w-6xl bg-slate-900 md:rounded-3xl shadow-[0_0_100px_rgba(0,0,0,1)] border-none md:border border-slate-800 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="relative h-32 md:h-64 flex-shrink-0">
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent z-10"></div>
          {character.portraitUrl ? (
            <img src={character.portraitUrl} alt={character.name} className="w-full h-full object-cover opacity-60 grayscale-[50%]" />
          ) : (
            <div className="w-full h-full bg-slate-800 flex items-center justify-center">
               <i className="fas fa-user-shield text-6xl md:text-8xl text-slate-700"></i>
            </div>
          )}
          <div className="absolute bottom-4 left-4 md:bottom-10 md:left-10 z-20">
            <h2 className="text-2xl md:text-6xl font-header text-white tracking-tighter uppercase mb-1 md:mb-2">{character.name}</h2>
            <div className="flex gap-3 md:gap-4 items-center">
              <span className="px-2 md:px-3 py-0.5 md:py-1 bg-amber-600/20 border border-amber-600/40 rounded-full text-amber-500 text-[8px] md:text-[10px] font-bold uppercase tracking-widest">{character.race}</span>
              <span className="text-slate-400 text-[10px] md:text-xs font-mono">{character.height} | {character.weight}</span>
            </div>
          </div>
          <button onClick={onClose} className="absolute top-4 right-4 z-30 w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black transition-colors">
            <i className="fas fa-times text-lg"></i>
          </button>
        </div>

        {/* Content Column */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Left Sidebar */}
          <div className="hidden md:block w-80 border-r border-slate-800 p-6 md:p-10 space-y-10 overflow-y-auto custom-scrollbar bg-slate-950/20">
            <section>
              <h3 className="text-[10px] font-header text-slate-500 uppercase tracking-widest mb-4">Description</h3>
              <p className="text-xs text-slate-400 leading-relaxed italic">"{character.description}"</p>
            </section>

            <section className="space-y-4">
              <h3 className="text-[10px] font-header text-slate-500 uppercase tracking-widest">Active Conditions</h3>
              <div className="flex flex-wrap gap-2">
                {character.conditions.map((c, i) => (
                  <span 
                    key={i} 
                    onMouseEnter={(e) => { e.stopPropagation(); setHoveredCondition(c); }}
                    onMouseLeave={() => setHoveredCondition(null)}
                    onMouseMove={handleMouseMove}
                    className="px-2 py-1 bg-amber-950/30 border border-amber-900/40 rounded text-[9px] font-bold text-amber-500 uppercase cursor-help transition-all hover:border-amber-500/60"
                  >
                    {c}
                  </span>
                ))}
              </div>
            </section>
            
            <section className="space-y-4">
              <h3 className="text-[10px] font-header text-slate-500 uppercase tracking-widest">Vitality Pools</h3>
              <StatBar label="Health" current={character.pools.hp.current} max={character.pools.hp.max} color="red" icon="fas fa-heart" />
              <StatBar label="Stamina" current={character.pools.stamina.current} max={character.pools.stamina.max} color="green" icon="fas fa-bolt" />
              <StatBar label="Mana" current={character.pools.mana.current} max={character.pools.mana.max} color="blue" icon="fas fa-magic" />
            </section>
          </div>

          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Improved Mobile Tab Bar */}
            <div className="flex border-b border-slate-800 bg-slate-900/60 overflow-x-auto scrollbar-none scroll-smooth">
              <div className="flex min-w-full md:min-w-0">
                {['Attributes', 'Skills', 'Spells', 'Memory', 'Codex'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`flex-1 md:flex-none px-6 md:px-8 py-5 text-[10px] font-bold uppercase tracking-[0.2em] transition-all relative whitespace-nowrap ${activeTab === tab ? 'text-amber-500 bg-amber-950/5' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    {tab}
                    {activeTab === tab && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 shadow-[0_0_10px_rgba(217,119,6,0.6)]"></div>}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 md:p-12 custom-scrollbar bg-slate-950/10">
              {/* Mobile-only Stats Summary */}
              <div className="md:hidden mb-8 grid grid-cols-2 gap-2">
                <div className="bg-slate-900/40 p-3 rounded border border-slate-800 flex justify-between items-center">
                   <span className="text-[9px] text-red-500 uppercase font-bold tracking-widest">HP</span>
                   <span className="text-xs font-mono font-bold">{Math.floor(character.pools.hp.current)}</span>
                </div>
                <div className="bg-slate-900/40 p-3 rounded border border-slate-800 flex justify-between items-center">
                   <span className="text-[9px] text-green-500 uppercase font-bold tracking-widest">SP</span>
                   <span className="text-xs font-mono font-bold">{Math.floor(character.pools.stamina.current)}</span>
                </div>
              </div>
              
              {renderTabContent()}
            </div>
            
            <div className="p-4 md:p-10 border-t border-slate-800 bg-slate-950/30 flex justify-end gap-3 md:gap-4">
               <button onClick={onClose} className="px-8 py-3 bg-slate-800 text-slate-400 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-slate-700 transition-colors">Close Dossier</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterSheet;