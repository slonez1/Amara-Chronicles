
import React from 'react';

interface StatBarProps {
  label: string;
  current: number;
  max: number;
  color: string;
  icon: string;
}

const StatBar: React.FC<StatBarProps> = ({ label, current, max, color, icon }) => {
  const percentage = Math.max(0, Math.min(100, (current / max) * 100));
  
  const getBarColor = () => {
    switch (color) {
      case 'red': return '#ef4444';
      case 'green': return '#22c55e';
      case 'blue': return '#3b82f6';
      case 'rose': return '#e11d48';
      default: return '#64748b';
    }
  };

  const getLabelColor = () => {
    switch (color) {
      case 'red': return 'text-red-400';
      case 'green': return 'text-green-400';
      case 'blue': return 'text-blue-400';
      case 'rose': return 'text-rose-400';
      default: return 'text-slate-400';
    }
  };

  return (
    <div className="flex flex-col mb-3">
      <div className="flex justify-between items-center mb-1 px-1">
        <span className={`text-[10px] font-bold uppercase tracking-wider flex items-center gap-2 ${getLabelColor()}`}>
          <i className={`${icon}`}></i>
          {label}
        </span>
        <span className="text-[10px] font-mono opacity-80">{Math.floor(current)} / {max}{label === 'Arousal' ? '%' : ''}</span>
      </div>
      <div className="w-full h-3 bg-slate-900 border border-slate-700/50 rounded-full overflow-hidden shadow-inner relative">
        <div 
          className="h-full transition-all duration-700 ease-out absolute left-0 top-0"
          style={{ 
            width: `${percentage}%`,
            backgroundColor: getBarColor(),
            boxShadow: color === 'rose' ? '0 0 15px rgba(225, 29, 72, 0.6)' : 'none'
          }}
        >
          <div className="w-full h-full bg-white/10 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
};

export default StatBar;
