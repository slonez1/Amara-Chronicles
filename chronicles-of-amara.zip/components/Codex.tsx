
import React, { useState } from 'react';
import { CodexEntry } from '../types';

interface CodexProps {
  entries: CodexEntry[];
}

const Codex: React.FC<CodexProps> = ({ entries }) => {
  const [selectedCategory, setSelectedCategory] = useState<CodexEntry['category'] | 'All'>('All');
  const [selectedEntry, setSelectedEntry] = useState<CodexEntry | null>(null);

  const categories: (CodexEntry['category'] | 'All')[] = ['All', 'NPC', 'Secret', 'Lore', 'History'];

  const filteredEntries = selectedCategory === 'All' 
    ? entries 
    : entries.filter(e => e.category === selectedCategory);

  return (
    <div className="flex h-full animate-in fade-in duration-500">
      {/* Index Column */}
      <div className="w-1/3 border-r border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-800 flex gap-1 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => { setSelectedCategory(cat); setSelectedEntry(null); }}
              className={`px-2 py-1 text-[9px] uppercase tracking-tighter rounded border transition-all ${selectedCategory === cat ? 'bg-amber-700/20 border-amber-600 text-amber-400' : 'border-slate-800 text-slate-500 hover:text-slate-300'}`}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
          {filteredEntries.map(entry => (
            <button
              key={entry.id}
              onClick={() => setSelectedEntry(entry)}
              className={`w-full text-left p-3 rounded transition-all group ${selectedEntry?.id === entry.id ? 'bg-slate-800/50 border-l-2 border-amber-500' : 'hover:bg-slate-900/40'}`}
            >
              <div className="text-[10px] text-slate-600 uppercase font-bold tracking-widest mb-1">{entry.category}</div>
              <div className="text-sm font-header text-slate-200 group-hover:text-amber-500 transition-colors">{entry.title}</div>
            </button>
          ))}
          {filteredEntries.length === 0 && (
            <div className="p-8 text-center text-slate-700 italic text-xs">The pages remain blank...</div>
          )}
        </div>
      </div>

      {/* Content Column */}
      <div className="w-2/3 p-10 overflow-y-auto custom-scrollbar bg-slate-950/20">
        {selectedEntry ? (
          <div className="animate-in slide-in-from-right-4 duration-300">
            <div className="flex justify-between items-baseline border-b border-slate-800 pb-4 mb-6">
              <h3 className="text-3xl font-header text-amber-500">{selectedEntry.title}</h3>
              <span className="text-[10px] text-slate-600 italic uppercase">Discovered in {selectedEntry.discoveredAt}</span>
            </div>
            <div className="prose prose-invert prose-slate max-w-none">
              <p className="text-lg leading-relaxed text-slate-300 first-letter:text-5xl first-letter:font-header first-letter:text-amber-600 first-letter:mr-3 first-letter:float-left first-letter:mt-1 italic">
                {selectedEntry.content}
              </p>
            </div>
            <div className="mt-12 flex justify-center">
              <div className="h-px w-24 bg-gradient-to-r from-transparent via-slate-700 to-transparent"></div>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center opacity-20">
            <i className="fas fa-book-dead text-8xl text-slate-600 mb-6"></i>
            <p className="font-header text-slate-500 tracking-widest uppercase">Select an entry from the ledger</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Codex;
